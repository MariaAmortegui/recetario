package com.example.aplicacion_final_maria.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material.MaterialTheme
import androidx.compose.material.darkColors
import androidx.compose.material.lightColors
import androidx.compose.runtime.Composable

private val DarkColorPalette = darkColors(
    primary = Champagne_pink,
    primaryVariant = Light_green,
    secondary = Myrtle_green,
    secondaryVariant = Redwood,
    background = Jet
)

private val LightColorPalette = lightColors(
    primary = Myrtle_green,
    primaryVariant = Light_green,
    secondary = Jet,
    secondaryVariant = Redwood,
    background = Champagne_pink

    /* Other default colors to override
    background = Color.White,
    surface = Color.White,
    onPrimary = Color.White,
    onSecondary = Color.Black,
    onBackground = Color.Black,
    onSurface = Color.Black,
    */
)

@Composable
fun APLICACION_FINAL_MARIATheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    content: @Composable () -> Unit
) {
    val colors = if (darkTheme) {
        LightColorPalette
    } else {
        LightColorPalette
    }

    MaterialTheme(
        colors = colors,
        typography = Typography,
        shapes = Shapes,
        content = content
    )
}