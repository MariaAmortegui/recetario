package com.example.aplicacion_final_maria.screens

import android.annotation.SuppressLint
import androidx.compose.foundation.Image
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import coil.compose.rememberAsyncImagePainter
import com.example.aplicacion_final_maria.R
import com.example.aplicacion_final_maria.models.Mireceta
import com.example.aplicacion_final_maria.nav.AppNav
import com.example.aplicacion_final_maria.ui.theme.Shapes
import com.google.firebase.firestore.ktx.firestore
import com.google.firebase.ktx.Firebase

@SuppressLint("UnusedMaterialScaffoldPaddingParameter")
@Composable
fun AddScreen(navController: NavController) {
    Scaffold(
        topBar = {
            TopAppBar {
                Text(
                    text = "¡NUEVA RECETA!",
                    textAlign = TextAlign.Center,
                    modifier = Modifier.fillMaxWidth(),
                    fontWeight = FontWeight.Bold,
                    fontSize = 30.sp,
                    color = Color.White,
                    fontFamily = FontFamily.Serif

                )
            } // Fin TopAppBar
        }, // Fin topBar
        floatingActionButton = {
            FloatingActionButton(modifier = Modifier
                .size(32.dp)
                .border(1.dp, color = Color.Black, shape = Shapes.small)
                .clip(Shapes.small),
                onClick = { navController.navigate(route = AppNav.HomeScreen.route) }) {
                Icon(
                    imageVector = Icons.Default.ArrowBack,
                    contentDescription = "Regresar",
                    tint = Color.White,
                ) // Fin Icon
            } // Fin del FAB
        }, // Fin del FAB externo
        floatingActionButtonPosition = FabPosition.End
    ) {
        BodyContent(navController)
    } // Fin de BodyContent()
} // Fin AddScreen

@Composable
fun BodyContent(navController: NavController) {
    var calificacion by remember { mutableStateOf("") }
    var foto by remember { mutableStateOf("") }
    var nombre by remember { mutableStateOf("") }
    var opinion by remember { mutableStateOf("") }
    var youtube by remember { mutableStateOf("") }
    var error by remember { mutableStateOf(false) }
    Box(modifier = Modifier.fillMaxSize()) {
        LazyColumn(
            modifier = Modifier
                .fillMaxWidth()
                .padding(all = 30.dp),
            verticalArrangement = Arrangement.Center,
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            item {
                Image(
                    modifier = Modifier
                        .size(250.dp)
                        .clip(CircleShape)
                        .border(5.dp, MaterialTheme.colors.onBackground, CircleShape),
                    painter = rememberAsyncImagePainter(R.drawable.nueva),
                    contentDescription = "Imagenes"
                )
                Spacer(modifier = Modifier.height(20.dp))
                TextField(
                    modifier = Modifier.fillMaxWidth(),
                    value = calificacion,
                    onValueChange = { calificacion = it },
                    label = { Text("Calificacion de la receta:") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number)
                )
                Spacer(modifier = Modifier.height(20.dp))
                TextField(
                    modifier = Modifier.fillMaxWidth(),
                    value = foto,
                    onValueChange = { foto = it },
                    label = { Text("Imagen de la receta:") }
                )
                Spacer(modifier = Modifier.height(20.dp))
                TextField(
                    modifier = Modifier.fillMaxWidth(),
                    value = nombre,
                    onValueChange = { nombre = it },
                    label = { Text("Nombre de la receta:") },
                )
                Spacer(modifier = Modifier.height(20.dp))
                TextField(
                    modifier = Modifier.fillMaxWidth(),
                    value = opinion,
                    onValueChange = { opinion = it },
                    label = { Text("Opinion de la receta:") },
                )
                Spacer(modifier = Modifier.height(20.dp))
                TextField(
                    modifier = Modifier.fillMaxWidth(),
                    value = youtube,
                    onValueChange = { youtube = it },
                    label = { Text("Link del video: ") },
                )
                Spacer(modifier = Modifier.height(20.dp))
                Button(
                    onClick = {
                        if (foto == "" || nombre == "" || calificacion == "" || opinion == "") {
                            error = true
                        } else {
                            val mireceta = Mireceta(
                                calificacion,
                                foto,
                                nombre,
                                opinion,
                                youtube
                            )
                            Firebase.firestore.collection("misrecetas").add(mireceta)
                            navController.navigate(AppNav.OpinionScreen.route)
                        } // Fin If
                    }, //Fin onClick
                    modifier = Modifier
                        .padding(vertical = 8.dp)
                        .fillMaxWidth()

                ) {
                    Text(
                        text = "AGREGAR RECETA",
                        fontFamily = FontFamily.Serif,
                        fontSize = 30.sp
                    )
                } // Fin Button
                if (error) {
                    DialogAlert(navController)
                } // Fin If
            } // Fin Item
        } // Fin LazyColumn
    } // Fin Box
} // Fin BodyContent

@Composable
fun DialogAlert(navController: NavController) {
    AlertDialog(
        onDismissRequest = { navController.navigate(AppNav.AddScreen.route) },
        confirmButton = {
            TextButton(onClick = { navController.navigate(AppNav.AddScreen.route) }) {
                Text(text = "Aceptar")
            }
        },
        title = { Text(text = "ERROR") },
        text = { Text(text = "¡TODOS LOS CAMPOS DEBEN DE ESTAR LLENOS!") }
    )
}
