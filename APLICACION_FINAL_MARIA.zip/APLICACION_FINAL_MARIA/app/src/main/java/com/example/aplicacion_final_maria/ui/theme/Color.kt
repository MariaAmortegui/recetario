package com.example.aplicacion_final_maria.ui.theme

import androidx.compose.ui.graphics.Color

val Jet = Color(0xFF3D3A4B)
val Champagne_pink = Color(0xFFE5D4CE)
val Redwood = Color(0xFFB2675E)
val Light_green = Color(0xFFA2FAA3)
val Myrtle_green = Color(0xFF32746D)
