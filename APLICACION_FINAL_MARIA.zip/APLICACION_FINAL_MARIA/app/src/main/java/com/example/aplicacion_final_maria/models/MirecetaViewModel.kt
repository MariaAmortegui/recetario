package com.example.aplicacion_final_maria.models

import androidx.compose.runtime.MutableState
import androidx.compose.runtime.State
import androidx.compose.runtime.mutableStateOf
import androidx.lifecycle.ViewModel
import com.google.firebase.firestore.ktx.firestore
import com.google.firebase.firestore.ktx.toObjects
import com.google.firebase.ktx.Firebase

class MirecetaViewModel:ViewModel() {
    private val _misrecetas = mutableStateOf<List<Mireceta>>(emptyList())
    val misrecetas : MutableState<List<Mireceta>>
        get() = _misrecetas
    private val query = Firebase.firestore.collection("misrecetas")
    init {
        query.addSnapshotListener{
                value, _ ->
            if (value != null){
                _misrecetas.value = value.toObjects()
            }//fin if
        }//fin listener
    }//fin init
}//fin class