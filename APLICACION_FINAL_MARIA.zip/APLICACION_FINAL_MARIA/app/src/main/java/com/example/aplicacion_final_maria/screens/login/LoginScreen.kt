package com.example.aplicacion_final_maria.screens.login

import android.util.Log
import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.text.ClickableText
import androidx.compose.material.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shadow
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.withStyle
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import com.example.aplicacion_final_maria.R


@Composable
fun LoginScreen(
    navController: NavController,
    isLoading: Boolean,
    onLoginClick: () -> Unit,
) {
    val logo = painterResource(R.drawable.imagen_icon)
    Column(
        modifier = Modifier.fillMaxSize(),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.SpaceAround
    ) {
        val offset = Offset(1.0f, 10.0f)
        Text(
            stringResource(R.string.Login_Title),
            style = TextStyle(
                color = MaterialTheme.colors.secondaryVariant,
                fontSize = 50.sp,
                shadow = Shadow(
                    color = Color.Gray,
                    offset = offset,
                    blurRadius = 5f
                )
            ),
            textAlign = TextAlign.Center,
            fontWeight = FontWeight.Bold
        ) // Fin Text Login_Title
        Image(
            modifier = Modifier
                .fillMaxWidth()
                .fillMaxHeight(0.3f)
                .padding(horizontal = 32.dp),
            painter = logo,
            contentDescription = null
        ) // Fin Image
        Text(
            stringResource(R.string.Sub_Title),
            style = MaterialTheme.typography.h4,
            textAlign = TextAlign.Center,
            modifier = Modifier.padding(10.dp)
        )
        if (isLoading) {
            CircularProgressIndicator()
        } else {
            Button(
                onClick = onLoginClick,
                colors = ButtonDefaults.buttonColors(backgroundColor = MaterialTheme.colors.secondary),
            )
            {
                Text(stringResource(R.string.Login_Cta), color = Color.White)
            } // Fin Button
        } // Fin If
        LegalText()
    } // Fin Column
} // Fin LoginScreen

@Composable
fun LegalText() {
    val anottatedString = buildAnnotatedString {
        append(stringResource(R.string.Text_Legal1))
        append(" ")
        pushStringAnnotation("URL", "app://terms")
        withStyle(
            style = SpanStyle(
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colors.secondary
            )
        ) {
            append(stringResource(R.string.Text_Legal2))
        } // Fin withStyle
        append(" ")
        pop()
        append(stringResource(R.string.Text_Legal3))
        append(" ")
        pushStringAnnotation("URL", "app://privacy")
        withStyle(
            style = SpanStyle(
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colors.secondary
            )
        ) {
            append(stringResource(R.string.Text_Legal4))
        } // Fin withStyle
        pop()
    } //fin anottatedString
    Box(contentAlignment = Alignment.Center) {
        ClickableText(
            modifier = Modifier.padding(24.dp),
            text = anottatedString
        ) { offset ->
            anottatedString.getStringAnnotations("URL", offset, offset)
                .firstOrNull()?.let { tag ->
                    Log.d("App", "Ha dado cick en ${tag.item}")
                } //fin del Offset
        } // Fin Text
    } // fin Box
} //fin LegalText
