package com.example.aplicacion_final_maria

import android.content.Intent
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.viewModels
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material.MaterialTheme
import androidx.compose.material.Surface
import androidx.compose.runtime.getValue
import androidx.compose.runtime.livedata.observeAsState
import androidx.compose.ui.Modifier
import com.example.aplicacion_final_maria.models.RecetaViewModel
import com.example.aplicacion_final_maria.nav.AppNavigation
import com.example.aplicacion_final_maria.screens.login.MainViewModel
import com.example.aplicacion_final_maria.ui.theme.APLICACION_FINAL_MARIATheme
import com.google.android.gms.auth.api.signin.GoogleSignIn
import com.google.android.gms.auth.api.signin.GoogleSignInAccount
import com.google.android.gms.tasks.Task

class MainActivity : ComponentActivity() {
    val viewModel by viewModels<RecetaViewModel>()
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            val viewModel: MainViewModel by viewModels()
            val isLoading by viewModel.isLoading().observeAsState(false)
            val condicion by viewModel.condicional().observeAsState(false)
            APLICACION_FINAL_MARIATheme {
                // A surface container using the 'background' color from the theme
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = MaterialTheme.colors.background

                ) {
                    AppNavigation(
                        condicion,
                        onClick = { viewModel.LoginWithGoogle(this@MainActivity)},
                        logOut = {viewModel.singOut(this@MainActivity)},
                        viewModel
                    )
                }
            }
        }
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        val viewModel: MainViewModel by viewModels()
        if (requestCode == 1) {
            val task: Task<GoogleSignInAccount> = GoogleSignIn.getSignedInAccountFromIntent(data)
            viewModel.finishLogin(task)
        } //Fin If
    } // Fin onActivityResult
}
