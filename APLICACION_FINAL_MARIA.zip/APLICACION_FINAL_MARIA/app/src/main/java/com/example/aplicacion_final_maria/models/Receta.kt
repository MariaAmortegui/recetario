package com.example.aplicacion_final_maria.models

data class Receta(
    val imagen: String = "",
    val nombre: String = "",
    val ingredientes: String = "",
    val procedimiento: String = "",
    val tiempo: String = "",
    val tipo: String = "",
    val dificultad: String = "",
)//fin data class
