package com.example.aplicacion_final_maria.models

data class Mireceta(
    val calificacion: String = "",
    val foto:String = "",
    val nombre:String = "",
    val opinion:String = "",
    val youtube:String = "",
)
