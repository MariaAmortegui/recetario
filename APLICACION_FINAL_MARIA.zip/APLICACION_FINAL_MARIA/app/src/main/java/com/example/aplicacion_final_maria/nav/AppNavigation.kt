package com.example.aplicacion_final_maria.nav

import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import com.example.aplicacion_final_maria.models.MirecetaViewModel
import com.example.aplicacion_final_maria.models.RecetaViewModel
import com.example.aplicacion_final_maria.screens.AddScreen
import com.example.aplicacion_final_maria.screens.HomeScreen
import com.example.aplicacion_final_maria.screens.InfoReceta
import com.example.aplicacion_final_maria.screens.OpinionScreen
import com.example.aplicacion_final_maria.screens.login.LoginScreen
import com.example.aplicacion_final_maria.screens.login.MainViewModel

@Composable
fun AppNavigation(
    condicional: Boolean,
    onClick: () -> Unit,
    logOut: () -> Unit,
    mainViewModel: MainViewModel,
) {
    val navController = rememberNavController()
    NavHost(
        navController = navController,
        startDestination = AppNav.LoginScreen.route
    ) {
        composable(route = AppNav.LoginScreen.route) {
            if (condicional) {
                LaunchedEffect(key1 = Unit) {
                    navController.navigate(AppNav.HomeScreen.route) {
                        popUpTo(AppNav.LoginScreen.route) {
                            inclusive = true
                        }//fin popupto
                    }// fin navcontroller
                }//fin launchedeffect
            } else {
                LoginScreen(
                    navController,
                    isLoading = false,
                    onLoginClick = onClick
                )
            }//fin if
        }//fin composable login
        composable(route = AppNav.HomeScreen.route) {
            HomeScreen(
                navController,
                RecetaViewModel(),
                logOut
            )
        }//fin composable home
        composable(route = AppNav.AddScreen.route) { AddScreen(navController) }
        composable(
            route = AppNav.InfoReceta.route,
            arguments = listOf(
                navArgument("imagen") { type = NavType.StringType },
                navArgument("nombre") { type = NavType.StringType },
                navArgument("dificultad") { type = NavType.StringType },
                navArgument("tiempo") { type = NavType.StringType },
                navArgument("tipo") { type = NavType.StringType },
                navArgument("ingredientes") { type = NavType.StringType },
                navArgument("procedimiento") { type = NavType.StringType }
            )
        ) {
            InfoReceta(
                navController,
                imagen = it.arguments?.getString("imagen") ?: "",
                nombre = it.arguments?.getString("nombre") ?: "",
                dificultad = it.arguments?.getString("dificultad") ?: "",
                tiempo = it.arguments?.getString("tiempo") ?: "",
                tipo = it.arguments?.getString("tipo") ?: "",
                ingredientes = it.arguments?.getString("ingredientes") ?: "",
                procedimiento = it.arguments?.getString("procedimiento") ?: "",
            )//fin inforeceta
        }//fin composable inforeceta
        composable(route = AppNav.OpinionScreen.route) {
            OpinionScreen(
                navController,
                MirecetaViewModel(),
                logOut
            )
        }//fin composable home
    }//fin navhost
}//fin fun appnavigation