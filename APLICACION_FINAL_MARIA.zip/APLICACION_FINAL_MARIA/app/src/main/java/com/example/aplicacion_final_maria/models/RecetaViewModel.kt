package com.example.aplicacion_final_maria.models

import androidx.compose.runtime.State
import androidx.compose.runtime.mutableStateOf
import androidx.lifecycle.ViewModel
import com.google.firebase.firestore.ktx.firestore
import com.google.firebase.firestore.ktx.toObjects
import com.google.firebase.ktx.Firebase

class RecetaViewModel: ViewModel() {
    private val _recetas = mutableStateOf<List<Receta>>(emptyList())
    val recetas : State<List<Receta>>
        get() = _recetas
    private val query = Firebase.firestore.collection("recetas")
    init {
        query.addSnapshotListener{
            value, _ ->
            if (value != null){
                _recetas.value = value.toObjects()
            }//fin if
        }//fin listener
    }//fin init
}//fin class