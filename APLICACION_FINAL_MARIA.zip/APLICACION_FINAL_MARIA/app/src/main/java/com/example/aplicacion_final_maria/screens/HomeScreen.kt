package com.example.aplicacion_final_maria.screens

import android.annotation.SuppressLint
import android.os.Handler
import android.os.Looper
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController
import coil.compose.rememberAsyncImagePainter
import com.example.aplicacion_final_maria.models.Receta
import com.example.aplicacion_final_maria.models.RecetaViewModel
import com.example.aplicacion_final_maria.nav.AppNav

@SuppressLint("UnusedMaterialScaffoldPaddingParameter")
@Composable
fun HomeScreen(
    navController: NavController,
    viewModel: RecetaViewModel,
    logOut:()->Unit
) {
    Scaffold(
        topBar = {
            TopAppBar {
                CompositionLocalProvider(
                    LocalContentAlpha provides ContentAlpha.high,
                    LocalTextStyle provides MaterialTheme.typography.h6
                ) {
                    Text(
                        text = "RECETARIO",
                        textAlign = TextAlign.Left,
                        modifier = Modifier
                            .fillMaxWidth()
                            .weight(1f)
                            .padding(10.dp),
                        fontFamily = FontFamily.Serif
                    )
                }
                CompositionLocalProvider(
                    LocalContentAlpha provides ContentAlpha.high
                ) {
                    IconButton(onClick = { navController.navigate(AppNav.HomeScreen.route) }) {
                        Icon(
                            imageVector = Icons.Default.Home,
                            contentDescription = "Inicio"
                        )//fin Icon
                    }//fin IconButton
                }
                CompositionLocalProvider(
                    LocalContentAlpha provides ContentAlpha.high
                ) {
                    IconButton(onClick = {
                        navController.navigate(AppNav.OpinionScreen.route)
                    }) {
                        Icon(
                            imageVector = Icons.Default.Microwave,
                            contentDescription = "mis recetas"
                        )//fin Icon
                    }//fin IconButton
                }
                IconButton(onClick = {
                    logOut()
                    Handler(Looper.getMainLooper()).postDelayed({
                        navController.navigate(AppNav.LoginScreen.route)
                    }, 2000)
                }) {
                    Icon(imageVector = Icons.Filled.Logout, contentDescription = "Cerrar sesion")
                }
            }
        }
    ) // Fin Scaffold
    {
        Box(
            modifier = Modifier
                .fillMaxSize()
        ) {
            Column {
                LazyColumn() {
                    items(viewModel.recetas.value) { receta ->
                        RecetaCard(receta, navController)
                    } // Fin Items
                } // Fin LazyColumn
            } // Fin Column-Box
        } // Fin Box
    } //Fin Scaffold
} // Fin ListaPeliculas

@Composable
fun RecetaCard(receta: Receta, navController: NavController) {
    Card(
        modifier = Modifier
            .padding(20.dp)
            .height(150.dp)
            .fillMaxWidth()
            .clickable {
                navController.navigate(
                    AppNav.InfoReceta.newroute(
                        receta.imagen,
                        receta.nombre,
                        receta.dificultad,
                        receta.tiempo,
                        receta.tipo,
                        receta.ingredientes,
                        receta.procedimiento
                    )
                )
            } // Fin clickable
    ) //Fin Card
    {
        Box(
            modifier = Modifier.fillMaxSize()
        ) {
            Image(
                painter = rememberAsyncImagePainter(receta.imagen),
                contentDescription = "",
                modifier = Modifier.fillMaxSize(),
                contentScale = ContentScale.FillWidth
            ) // Fin Image
            Text(
                text = receta.nombre,
                textAlign = TextAlign.Center,
                modifier = Modifier
                    .align(Alignment.Center)
                    .fillMaxWidth()
                    .background(MaterialTheme.colors.background),
                fontSize = MaterialTheme.typography.h5.fontSize,
                fontFamily = FontFamily.Serif,
                color = Color.Black
            )
        } // Fin Column
    } // Fin Card
} // Fin RecetaCard