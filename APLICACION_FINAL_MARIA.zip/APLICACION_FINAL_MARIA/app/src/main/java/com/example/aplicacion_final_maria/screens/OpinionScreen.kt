package com.example.aplicacion_final_maria.screens

import android.annotation.SuppressLint
import android.os.Handler
import android.os.Looper
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalUriHandler
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController
import coil.compose.rememberAsyncImagePainter
import com.example.aplicacion_final_maria.R
import com.example.aplicacion_final_maria.models.Mireceta
import com.example.aplicacion_final_maria.models.MirecetaViewModel
import com.example.aplicacion_final_maria.nav.AppNav

@SuppressLint("UnusedMaterialScaffoldPaddingParameter")
@Composable
fun OpinionScreen(
    navController: NavController,
    viewModel: MirecetaViewModel,
    logOut: () -> Unit,
) {
    Scaffold(topBar = {
        TopAppBar {
            CompositionLocalProvider(
                LocalContentAlpha provides ContentAlpha.high,
                LocalTextStyle provides MaterialTheme.typography.h6
            ) {
                Text(
                    text = "MIS RECETAS",
                    textAlign = TextAlign.Center,
                    modifier = Modifier
                        .fillMaxWidth()
                        .weight(1f),
                    fontFamily = FontFamily.Serif
                )
            }
            CompositionLocalProvider(
                LocalContentAlpha provides ContentAlpha.high
            ) {
                IconButton(onClick = {
                    navController.navigate(AppNav.HomeScreen.route)
                }) {
                    Icon(
                        imageVector = Icons.Default.Home, contentDescription = "Inicio"
                    )//fin Icon
                }//fin IconButton
            }
            CompositionLocalProvider(
                LocalContentAlpha provides ContentAlpha.high
            ) {
                IconButton(onClick = { navController.navigate(AppNav.OpinionScreen.route) }) {
                    Icon(
                        imageVector = Icons.Default.Microwave,
                        contentDescription = "mis recetas"
                    )//fin Icon
                }//fin IconButton
            }
            IconButton(onClick = {
                logOut()
                Handler(Looper.getMainLooper()).postDelayed({
                    navController.navigate(AppNav.LoginScreen.route)
                }, 2000)
            }) {
                Icon(imageVector = Icons.Filled.Logout, contentDescription = "Cerrar sesion")
            }
        }
    }, floatingActionButton = {
        FloatingActionButton(modifier = Modifier.size(32.dp),
            onClick = { navController.navigate(AppNav.AddScreen.route) }) {
            Icon(
                imageVector = Icons.Default.AddCircle,
                contentDescription = "Agregar",
                tint = Color.White
            )//fin Icon
            Text(text = "Agregar opinión")
        }
    }) // Fin Scaffold
    {
        Box(
            modifier = Modifier.fillMaxSize()
        ) {
            Column {
                Spacer(modifier = Modifier.height(30.dp))
                LazyColumn() {
                    items(viewModel.misrecetas.value) { mireceta ->
                        MirecetaCard(mireceta, navController)
                    } // Fin Items
                } // Fin LazyColumn
            } // Fin Column-Box
        } // Fin Box
    } //Fin Scaffold
} // Fin ListaPeliculas

@Composable
fun MirecetaCard(
    mireceta: Mireceta,
    navController: NavController,
    modifier: Modifier = Modifier,
    elevation: Dp = 1.dp,
    border: BorderStroke? = null,
    background: Color = MaterialTheme.colors.surface,
    contentColor: Color = contentColorFor(background),
    shape: Shape = MaterialTheme.shapes.medium,
) {
    Card(
        backgroundColor = background,
        contentColor = contentColor,
        shape = shape,
        elevation = elevation,
        modifier = modifier,
    ) //Fin Card
    {

        Column() {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(72.dp)
                    .padding(start = 16.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Box(
                    modifier = Modifier
                        .background(color = Color.LightGray, shape = CircleShape)
                        .size(40.dp), contentAlignment = Alignment.Center
                ) {
                    Image(
                        painter = painterResource(R.drawable.imagen_user_foreground),
                        contentDescription = "",
                        modifier = Modifier.fillMaxWidth(),
                        contentScale = ContentScale.FillWidth
                    ) // Fin Image
                }
                Spacer(modifier = Modifier.width(32.dp))
                Column(
                    modifier = Modifier.fillMaxWidth(),
                ) {
                    Text(
                        text = mireceta.nombre,
                        style = MaterialTheme.typography.h4,
                        fontFamily = FontFamily.Serif
                    )//fin text nombre
                }
            }
            Image(
                painter = rememberAsyncImagePainter(mireceta.foto),
                contentDescription = "imagen receta",
                Modifier
                    .background(color = Color.LightGray)
                    .fillMaxWidth()
                    .height(194.dp)
            )

            Row(Modifier.padding(start = 16.dp, end = 24.dp, top = 16.dp)) {

                // Texto de ayuda
                CompositionLocalProvider(LocalContentAlpha provides ContentAlpha.medium) {
                    Text(
                        text = mireceta.opinion,
                        style = MaterialTheme.typography.h5,
                        fontFamily = FontFamily.Serif
                    )
                }
            }

            Spacer(modifier = Modifier.height(24.dp))

            CompositionLocalProvider(LocalContentAlpha provides ContentAlpha.medium) {
                Box(
                    Modifier
                        .padding(horizontal = 8.dp)
                        .fillMaxWidth()
                ) {
                    Row(modifier = Modifier.align(Alignment.Center)) {
                        Icon(
                            imageVector = Icons.Default.HotelClass, contentDescription = null
                        )
                        Text(
                            text = "Calificación: " + mireceta.calificacion,
                            style = MaterialTheme.typography.h5,
                            fontFamily = FontFamily.Serif
                        )
                    }
                    Row(modifier = Modifier.align(Alignment.CenterEnd)) {
                        Icon(
                            imageVector = Icons.Default.TravelExplore,
                            contentDescription = null,
                        )
                        val uriHandler = LocalUriHandler.current
                        Text(
                            text = "Youtube", modifier = Modifier.clickable {
                                uriHandler.openUri(mireceta.youtube)
                            },// Fin Clickable
                            fontFamily = FontFamily.Serif
                        ) //  Fin Text
                    }
                    Row(modifier = Modifier.align(Alignment.CenterStart)) {
                        var like by remember { mutableStateOf(false) }
                        IconButton(onClick = { /*TODO*/ }) {
                            Icon(
                                modifier = Modifier.clickable {
                                    like = !like
                                },
                                imageVector = if (like) Icons.Default.Favorite
                                else Icons.Default.FavoriteBorder,
                                contentDescription = null,
                                tint = if (like) Color.Black
                                else Color.Gray
                            )
                        }
                    }
                    Spacer(modifier = Modifier.height(20.dp))
                }
            }
        }
    } // Fin Card
    Spacer(modifier = Modifier.height(30.dp))
} // Fin MirecetaCard