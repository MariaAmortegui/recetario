package com.example.aplicacion_final_maria.screens

import android.annotation.SuppressLint
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Share
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.intl.Locale
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.text.toUpperCase
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController
import coil.compose.rememberAsyncImagePainter
import com.example.aplicacion_final_maria.nav.AppNav


@SuppressLint("UnusedMaterialScaffoldPaddingParameter")
@Composable
fun InfoReceta(
    navController: NavController,
    imagen: String,
    nombre: String,
    dificultad: String,
    tiempo: String,
    tipo: String,
    ingredientes: String,
    procedimiento: String,
) {
    Scaffold(
        topBar = {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(15.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
            ) {
                Icon(
                    modifier = Modifier.clickable { navController.navigate(AppNav.HomeScreen.route) },
                    imageVector = Icons.Default.ArrowBack,
                    contentDescription = null,
                    tint = Color.Black
                )
                Text(
                    text = nombre.toUpperCase(Locale.current),
                    textAlign = TextAlign.Center,
                    fontWeight = FontWeight.Bold,
                    fontFamily = FontFamily.Serif
                )
            } // Fin Row
        }, // Fin topBar
    ) {
        BodyInformation(
            navController,
            imagen,
            nombre,
            dificultad,
            tiempo,
            tipo,
            ingredientes,
            procedimiento
        )
    } // Fin BodyInformation
} // Fin InformacionPeli

@Composable
fun BodyInformation(
    navController: NavController,
    imagen: String,
    nombre: String,
    dificultad: String,
    tiempo: String,
    tipo: String,
    ingredientes: String,
    procedimiento: String,
) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colors.background)
    ) {
        Image(
            painter = rememberAsyncImagePainter(imagen),
            contentDescription = "Imagen",
            modifier = Modifier
                .fillMaxWidth()
                .size(200.dp)
        )
        Spacer(modifier = Modifier.height(10.dp))
        LazyColumn(
            modifier = Modifier.fillMaxSize()
        ) {
            item {
                Column(
                    modifier = Modifier.fillMaxSize(),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.Center
                ) {
                    Surface(
                        modifier = Modifier
                            .fillMaxWidth()
                            .wrapContentHeight(),
                        color = Color.White,
                        shape = RoundedCornerShape(
                            topStartPercent = 8,
                            topEndPercent = 8
                        )
                    ) {
                        Column(
                            horizontalAlignment = Alignment.CenterHorizontally,
                            verticalArrangement = Arrangement.Center,
                            modifier = Modifier.padding(20.dp)
                        ) {
                            Spacer(modifier = Modifier.height(10.dp))
                            Text(
                                text = "🎚️  Dificultad: " + dificultad,
                                fontFamily = FontFamily.Serif
                            )
                            Spacer(modifier = Modifier.height(10.dp))
                            Text(
                                text = "⏱️Tiempo de cocción: " + tiempo,
                                fontFamily = FontFamily.Serif
                            )
                            Spacer(modifier = Modifier.height(10.dp))
                            Text(
                                text = "🥞 Hora de realización: " + tipo,
                                fontFamily = FontFamily.Serif
                            )
                            Spacer(modifier = Modifier.height(10.dp))
                            Text(
                                text = "🥔 Ingredientes: \n" + ingredientes,
                                fontFamily = FontFamily.Serif,
                                textAlign = TextAlign.Justify
                            )
                            Spacer(modifier = Modifier.height(10.dp))
                            Text(
                                text = "🔢 Procedimiento: \n" + procedimiento,
                                fontFamily = FontFamily.Serif,
                                modifier = Modifier.padding(bottom = 20.dp),
                                textAlign = TextAlign.Justify
                            )
                        }
                    }
                }
            } // Fin Column
        }
    }
} // Fin BodyInformation
