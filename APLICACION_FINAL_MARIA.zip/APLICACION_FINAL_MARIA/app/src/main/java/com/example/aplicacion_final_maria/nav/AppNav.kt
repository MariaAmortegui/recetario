package com.example.aplicacion_final_maria.nav

import java.net.URLEncoder
import java.nio.charset.StandardCharsets

sealed class AppNav(
    val route:String
){
    object LoginScreen : AppNav(route = "LoginScreen")
    object HomeScreen : AppNav(route = "HomeScreen")
    object AddScreen : AppNav(route = "AddScreen")
    object OpinionScreen : AppNav(route = "OpinionScreen")
    object InfoReceta : AppNav(route = "InfoReceta/{imagen}/{nombre}/{dificultad}/{tiempo}/{tipo}/{ingredientes}/{procedimiento}"){
        fun String.encodeUrl() = URLEncoder.encode(this, StandardCharsets.UTF_8.toString())
        fun newroute(imagen:String,nombre:String,dificultad:String,tiempo:String,tipo:String,ingredientes:String,procedimiento:String):String{
            return "InfoReceta/${imagen.encodeUrl()}/$nombre/$dificultad/$tiempo/$tipo/$ingredientes/$procedimiento"
        }// fin fun newroute
    }// fin inforeceta
}// fin sealed class
